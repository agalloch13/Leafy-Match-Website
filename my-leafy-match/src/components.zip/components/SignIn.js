import React, { useState } from 'react';
import '../styles.css';

const SignIn = () => {
  const [isSignIn, setIsSignIn] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const toggleForm = () => {
    setIsSignIn(!isSignIn);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        // Login successful
        // Redirect or perform any other action
        console.log('Login successful');
      } else {
        // Login failed
        const errorData = await response.json();
        console.error('Login failed:', errorData.error);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <>
      <div className="container my-5">
        <div className="row">
          <div className="col-md-6 mx-auto">
            {
              isSignIn ? (
                <>
                  <h2>Sign In</h2>
                  <form onSubmit={handleSubmit}>
                    <div className="form-group">
                      <input type="email" className="form-control" placeholder="Email" name="email" value={formData.email} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                      <input type="password" className="form-control" placeholder="Password" name="password" value={formData.password} onChange={handleChange} required />
                    </div>
                    <button type="submit" className="btn btn-primary">Sign In</button>
                  </form>
                  <p className="mt-3">Don't have an account? <span className="text-primary" style={{ cursor: 'pointer' }} onClick={toggleForm}>Sign Up</span></p>
                </>
              ) : (
                <>
                  <h2>Sign Up</h2>
                  <form>
                    <div className="form-group">
                      <input type="text" className="form-control" placeholder="Name" required />
                    </div>
                    <div className="form-group">
                      <input type="email" className="form-control" placeholder="Email" required />
                    </div>
                    <div className="form-group">
                      <input type="password" className="form-control" placeholder="Password" required />
                    </div>
                    <button type="submit" className="btn btn-primary">Sign Up</button>
                  </form>
                  <p className="mt-3">Already have an account? <span className="text-primary" style={{ cursor: 'pointer' }} onClick={toggleForm}>Log In</span></p>
                </>
              )
            }
          </div>
        </div>
      </div>
    </>
  );
};

export default SignIn;